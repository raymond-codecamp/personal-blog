import {
    SET_UPLOAD,
    SET_UPLOAD_PROGRESS,
    SET_LOADING,
    SET_PUBLICURL

} from 'utils/constants';

const initialValues = {
    isLoading: true,
    uploadPercent: 0,
    isUpload: false,
    publicURL: '',
};

export const blogReducer = (state = initialValues, action) => 
{
    switch(action.type)
    {
        case SET_UPLOAD_PROGRESS : return {
            ...state,
            uploadPercent: action.payload,
        }; 
        case SET_UPLOAD: return{
            ...state,
            isUpload: action.payload,
        }; 
        case SET_LOADING : return{
            ...state,
            isLoading: action.payload,
        };
        case SET_PUBLICURL : return{
            ...state,
            publicURL: action.payload,
        };
        default: return state;
    }
}